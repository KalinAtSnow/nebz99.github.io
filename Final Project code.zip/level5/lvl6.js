function AddHint1(){

    this.document.getElementById("hint").innerText = "so for this one you should look at element IDs for help"
}