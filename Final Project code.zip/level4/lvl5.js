function AddHint1(){

    this.document.getElementById("hint").innerText = "not much of a hint, but it may help to go back and see previous hint if you randomly cliked around and found it"
}