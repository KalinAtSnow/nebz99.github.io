
function AddHint1(){

    this.document.getElementById("hint").innerText = "Actually you should inspect the code, it might be helpful on some of these challenges"
}
function AddHint2(){

};